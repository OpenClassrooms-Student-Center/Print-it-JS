const slides = [
	{
		"image":"images/slideshow/slide1.jpg",
		"tagLine":"<p>Impressions tous formats <span>en boutique et en ligne</span></p>"
	},
	{
		"image":"images/slideshow/slide2.jpg",
		"tagLine":"<p>Tirages haute définition grand format <span>pour vos bureaux et events</span></p>"
	},
	{
		"image":"images/slideshow/slide3.jpg",
		"tagLine":"<p>Grand choix de couleurs <span>de CMJN aux pantones</span></p>"
	},
	{
		"image":"images/slideshow/slide3.jpg",
		"tagLine":"<p>Autocollants <span>avec découpe laser sur mesure</span></p>"
	}
]
